//alert("JavaScript works!");



//// functions
function basketballTeams() {
//
////
//
//    // local variables
    var sportsTeams = ["Pistons", "Cavaliers", "Heat", "Warriors"];
    var cities = ["Detroit ", "Cleveland ", "Miami ", "San Francisco "];
//
    // loops
    for (var i = 0; i < sportsTeams.length; i++) {
        console.log(cities[i] + sportsTeams[i] + " is my favorite basketball team.");

    }

    //array Methods
    sportsTeams.push("Spurs");
    cities.push("San Antonio ");

    for (var i = 0; i < sportsTeams.length; i++) {
        console.log(cities[i] + sportsTeams[i] + " is my favorite basketball team.");


    }
}
basketballTeams();
